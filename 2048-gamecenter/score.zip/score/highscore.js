// Express initialization from Ming's example
var express = require("express");
var app = express(express.logger());
app.use(express.bodyParser());
app.set('title', '2048-gamecenter');
app.use(express.json());
app.use(express.urlencoded());
//var jade = require('jade');
//var jadefn = jade.compile(jadeTemplate);

// Mongo initialization from Ming's example
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 
    'mongodb://localhost/scorecenter';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function(error, databaseConnection) {
    db = databaseConnection;
});

app.all('*', function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    next();
});

/*
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    next();
});
*/


app.post('/submit.json', function(request, response) {
    reqscore = request.body.score;
    requsername = request.body.username;
    reqgrid = request.body.grid;
    date = new Date();
    if (reqscore != undefined && reqgrid != undefined && requsername 
        != undefined) {
        reqscore = parseInt(reqscore);
        scoreDoc = {};
        scoreDoc.username = requsername,
        scoreDoc.score = reqscore,
        scoreDoc.grid = reqgrid,
        scoreDoc.created_at = date.getMonth() + 1 + "/" + date.getDate() 
            + "/" + date.getFullYear() + " " + date.getHours() + ":" + 
            date.getMinutes()
        
        db.collection('scores', function(error, collection) {
            collection.insert(scoreDoc, function(error, saved) {
                response.send(200);
            });
        });
    }

    
});

app.get('/scores.json', function(request, response) {
    reqname = request.query.username;
    if (reqname != undefined) {
        db.collection('scores', function(error, collection) {
            collection.find({username:reqname}).sort({score:-1}).toArray(function(error, cursor) {
                response.send(cursor);
            });
        });
    }
    else {
        var empty_arr = [];
        response.send(empty_arr);
    }
});

app.get('/', function(request, response) {
    var displaypage = "<!DOCTYPE html><html><head><title>2048 Scores</title></head><body><h1>2048 High Scores</h1><table><tr><th>Username</th><th>Score</th><th>Timestamp</th></tr>";
    db.collection('scores', function(error, collection) {
        collection.find().sort({score:-1}).toArray(function(error, cursor) {
            if (!error) {
                for (var i = 0; i < cursor.length; i++) {
                    displaypage += "<tr>" + "<td>" + cursor[i].username + "</td>" + "<td>" + cursor[i].score + "</td>" + "<td>" + cursor[i].created_at + "</td>" + "</tr>";
                }
                displaypage += "</table></html>";
                response.send(displaypage);
            }
        });
    });
    //response.send("<h1>2048 High Scores</h1><table><tr><th>Username</th><th>Score</th><th>Timestamp</th></tr></table>");
    //response.send(displaypage);


});

app.listen(process.env.PORT || 5000);