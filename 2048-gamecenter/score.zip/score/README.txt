Daniel Kim
dkim06

1. After much suffering and toil, the program meets specification and does not
seem to fail. 

2. Help from: Jasper, Ming, Arlo, Stefan

3. Hours spent: 10

4. Written in .txt format

5. The score and grid are part of the GameManager object of the game. These
are in the game_manager.js file. 

6. In the game_manager.js file, the if statement in GameManager.actuate that
checks to see if the game is over sends a jQuery post to my web app that 
contains the username, grid, and score. Also the username is entered by the
player in a text window once the game is ended. Also, the cloned index.html
has a script tag that links to jQuery. 
